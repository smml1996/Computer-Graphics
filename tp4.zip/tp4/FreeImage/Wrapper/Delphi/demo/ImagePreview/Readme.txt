This is a simple image viewing application that uses the FreeImage library to display images in many different formats.

The app displays the image whose name is passed in as a command line argument.


To compile the app you will also need the Graphics32 library available from www.g32.org. It has been tested with version 1.5.1 of Graphics32.

SJB.
